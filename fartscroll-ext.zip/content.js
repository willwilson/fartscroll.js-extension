$(document).on('ready', function(){
  $(document).fartscroll(200);
});